# let's import the flask

from flask import Flask,  Response
import json
import os
from flask_restful import Resource,Api,reqparse,abort


app = Flask(__name__)

api=Api(app)

todos={
    1:{"task 1":"write hellow world","summary 1":"write the code using html"},
    2:{"task 2":"write hellow world","summary 2":"write the code using html"},
    3:{"task 3":"write hellow world","summary 3":"write the code using html"}

}
class Todos(Resource):
    def get(self,id):
        return todos[id]

api.add_resource(Todos,"/todos/<int:id>")

# todos ={
#     1:{"task":"Word world program",
#     "summary":"Ok Ok"
#     },
#     2:{"task":"Word world program",
#     "summary":"Uff Uff"
#     },
#     3:{"task":"Word world program",
#     "summary":"Wah Wah"
#     },
#     4:{"task":"Word world program",
#     "summary":"Hye Hye"
#     }
    
# }
# task_post_args=reqparse.RequestParser()
# task_post_args.add_argument("task",type=str,help="Task Requird.",required=True)
# task_post_args.add_argument("summary",type=str,help="summary Requird.",required=True)

# class helloworld(Resource):
#     def get(self):
#         return {"data":"Hello,world!"}

# class helloname(Resource):
#     def get(self,name):
#         return {"data":"Hello,{}".format(name)}

# class Todos(Resource):
#     def get(self,id):
#         return todos[id]
#     def post(self,id):
#         args=task_post_args.parse_args()
#         if id in todos:
#             abort(409,"Task id ready")
#         todos[id]={"task":args["task"],"summary":args["summary"]}
#         return todos[id]
# class uff(Resource):
#     def get(self):
#         return todos

# api.add_resource(helloworld,"/helloword")
# api.add_resource(helloname,"/helloword/<string:name>")
# api.add_resource(Todos,"/todos/<int:id>")
# api.add_resource(uff,"/todos")


 
if __name__ == '__main__':
    app.run(debug=True)