# Let's import the necessary libraries
from flask import Flask, render_template
import os
import pymongo  # Importing pymongo

MONGODB_URI = 'mongodb://localhost:27017'
client = pymongo.MongoClient(MONGODB_URI)
dt = client['test'] 
db = client['thirty_days_of_python']  # Assuming you want to use the 'test' database

# students = [
#     {'name': 'David', 'country': 'UK', 'city': 'London', 'age': 34},
#     {'name': 'John', 'country': 'Sweden', 'city': 'Stockholm', 'age': 28},
#     {'name': 'Sami', 'country': 'Finland', 'city': 'Helsinki', 'age': 25},
#         {'name': 'David', 'country': 'UK', 'city': 'London', 'age': 34},
#     {'name': 'John', 'country': 'Sweden', 'city': 'Stockholm', 'age': 28},
#     {'name': 'Sami', 'country': 'Finland', 'city': 'Helsinki', 'age': 25},
#         {'name': 'David', 'country': 'UK', 'city': 'London', 'age': 34},
#     {'name': 'John', 'country': 'Sweden', 'city': 'Stockholm', 'age': 28},
#     {'name': 'Sami', 'country': 'Finland', 'city': 'Helsinki', 'age': 25},
# ]

# for student in students:
#     db.students.insert_one(student)



# -------Select statement---------------

# student = db.students.find_one({'name': 'John'})
# print(student)


# ------------Select All Statement------------------

# students = db.students.find()
# for student in students:
#     print(student)

#------------Data Except-------------------
# # students = db.students.find({}, {"_id":0,  "name": 1, "country":1}) # 0 means not include and 1 means include
# for student in students:
#     print(student)

# -------------Find with Query-----------------------
# Query={
#     "name":"David"
# }
# students = db.students.find(Query)
# for student in students:
#     print(student)


# query = {"age":{"$lt":30}}
# students = db.students.find(query)
# for student in students:
#     print(student)

# ---------------limit to display-------------------
# students = db.students.find().limit(5)
# for student in students:
#     print(student)

# ---------------sort to display-------------------

# students = db.students.find().sort('name')
# for student in students:
#     print(student)

# print("_______________")
# students = db.students.find().sort('name',-1)
# for student in students:
#     print(student)

# ----------------- Update data -------------------

# query = {'age':250}
# new_value = {'$set':{'age':38}}

# db.students.update_one(query, new_value)
# # lets check the result if the age is modified
# for student in db.students.find():
#     print(student)


# ------------Delete One ------------------
# query = {'age':25}

# db.students.delete_one(query)

# for student in db.students.find():
#     print(student)

# query = {'age':25}

# db.students.delete_many(query)

# for student in db.students.find():
#     print(student)

# ---------- Drop dataset--------------------
# dt.students.drop()


app = Flask(__name__)

if __name__ == '__main__':
    # For deployment, we use the environment variable for the port
    port = int(os.environ.get("PORT", 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
